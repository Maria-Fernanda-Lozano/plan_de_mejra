package davi_plata;
public class ingresar {
private  String nombre_usuario;
private int contraseña;
public ingresar(String nombre_usuario, int contraseña) {
    this.nombre_usuario = nombre_usuario;
    this.contraseña = contraseña;
}
public String getNombre_usuario() {
    return nombre_usuario;
}
public void setNombre_usuario(String nombre_usuario) {
    this.nombre_usuario = nombre_usuario;
}
public int getContraseña() {
    return contraseña;
}
public void setContraseña(int contraseña) {
    this.contraseña = contraseña;
}

public void iniciar() {
    
}

    

    
}
