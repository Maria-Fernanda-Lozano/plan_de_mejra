package davi_plata;
public class recarga {
    private int num_tel, valor_recarga;

    public recarga(int num_tel, int valor_recarga) {
        this.num_tel = num_tel;
        this.valor_recarga = valor_recarga;
    }

    public int getNum_tel() {
        return num_tel;
    }

    public void setNum_tel(int num_tel) {
        this.num_tel = num_tel;
    }

    public int getValor_recarga() {
        return valor_recarga;
    }

    public void setValor_recarga(int valor_recarga) {
        this.valor_recarga = valor_recarga;
    }
    
    
}
